const Skills = () => {
  return (
    <div>
      <h1>기술 스택 페이지</h1>
    </div>
  );
};

export default Skills;
