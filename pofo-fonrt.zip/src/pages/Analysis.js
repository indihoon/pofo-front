const Analysis = () => {
  return <h1>페이지 분석 페이지</h1>;
};

export default Analysis;
